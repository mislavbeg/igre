﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

	public static GameManager gameManager;
	public float bestScore;
	public int currentLvl = 1;

	public GameObject player;
	public GameObject lvlProgress;
	public GameObject finish;

	public GameObject endScreen;
	public GameObject lvlSegment;
	public GameObject lvlFinish;

	public float numbah;
	public float speedBoost = 0.1f;
	// Use this for initialization
	void Awake () {

		if (gameManager == null)
		{
			gameManager = this;
			DontDestroyOnLoad(gameObject);			
			
		}
		else
		{
			Destroy(gameObject);
		}

		
		finish = GameObject.Find("LevelFinish");
		player = GameObject.Find("Player");
		lvlProgress = GameObject.Find("ProgressBarFront");
		endScreen = GameObject.Find("PanelEndHolder");

		//GenerateLevel(currentLvl);

	}
	
	// TU STARTA FINISH
	void Update () {

		if (finish==null)
		{
			finish = GameObject.Find("LevelFinish(Clone)");
		}
		if (player!=null && finish!=null )
		{
			if (player.transform.position.z > finish.transform.position.z )
			{				

				player.GetComponent<PlayerController>().StartCoroutine("Finish");
			}

			lvlProgress.transform.localScale = new Vector3(player.transform.position.z / finish.transform.position.z, 1, 1);
		}
						
		  
	}

	public IEnumerator ResetVariables()
	{
		yield return new WaitForSeconds(1);
		finish = GameObject.Find("LevelFinish");		
		player = GameObject.Find("Player");
		lvlProgress = GameObject.Find("ProgressBarFront");
		endScreen = GameObject.Find("PanelEndHolder");
	}

	public void GenerateLevel(int lvlNumber)
	{		
		for (int i = 0; i < 10+lvlNumber; i++)
		{
			GameObject segment = Instantiate(lvlSegment, GameObject.Find("Level").transform);
			segment.transform.position = new Vector3(0,0, 4 + i * 9);

			if (segment==null)
			{
				Debug.Log("lol 4 real");
			}


			float rng1 = Random.Range(1.2f, 2f);
			

			Transform wallL = segment.transform.Find("wallL").GetChild(0).transform;
			Transform wallR = segment.transform.Find("wallR").GetChild(0).transform;

			wallL.localScale = new Vector3(1+rng1*numbah, 2, 1);
			wallL.transform.localPosition = new Vector3(wallL.transform.localPosition.x+ rng1 * numbah/2, wallL.transform.localPosition.y, wallL.transform.localPosition.z);

			wallR.transform.localScale = new Vector3(1 + rng1 * numbah, 2, 1);
			wallR.transform.localPosition = new Vector3(wallR.transform.localPosition.x + rng1 * numbah / 2, wallR.transform.localPosition.y, wallR.transform.localPosition.z);
			
	
			float rng2 = Random.Range(0.8f, 1.3f);


			Transform holeL = segment.transform.Find("holeL").GetChild(0).transform;
			Transform holeR = segment.transform.Find("holeR").GetChild(0).transform;



			
			 
			holeL.localScale = new Vector3(1 + rng2 * numbah, holeL.localScale.y, holeL.localScale.z);
			holeL.localPosition = new Vector3(holeL.transform.localPosition.x + rng2*numbah/2, holeL.localPosition.y, holeL.localPosition.z);

			holeR.localScale = new Vector3(1 + rng2 * numbah,holeL.localScale.y, holeL.localScale.z);
			holeR.localPosition = new Vector3(holeR.localPosition.x + rng2*numbah/2, holeR.localPosition.y, holeR.localPosition.z);

			/*
			holeL.localScale = new Vector3(1 , 2, 1);
			holeL.transform.localPosition = new Vector3(holeL.transform.localPosition.x, holeL.transform.localPosition.y, holeL.transform.localPosition.z);

			holeR.transform.localScale = new Vector3(1 , 2, 1);
			holeR.transform.localPosition = new Vector3(holeR.transform.localPosition.x , holeR.transform.localPosition.y, holeR.transform.localPosition.z);*/

		}
		GameObject finishHelo = Instantiate(lvlFinish);
		finishHelo.transform.position= new Vector3(0, 0, 4 + (10+lvlNumber) * 9 -4.5f);
		GameObject segment2 = Instantiate(lvlSegment, GameObject.Find("Level").transform);
		segment2.transform.position = new Vector3(0, 0, 4 + (10 + lvlNumber) * 9);

		
	}

	public void NextLevel()
	{
		
		currentLvl++;
		SceneManager.LoadScene("ProceduralLevel - safe");
		StartCoroutine("delayScore");

		StartCoroutine("Next");
	}

	public IEnumerator Next()
	{
		yield return new WaitForSeconds(1);
		GenerateLevel(currentLvl);
		StartCoroutine("ResetVariables");		

	}

	public IEnumerator delayScore()
	{
		yield return new WaitForSeconds(1);
		bestScore = 0;
	}

}
