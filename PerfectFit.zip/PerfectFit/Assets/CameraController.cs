﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {
	public PlayerController player;
	public Vector3 move;
	//public Vector3 startPosition;
	// Use this for initialization
	void Start () {
	//	startPosition = transform.position;
		player = GameObject.Find("Player").GetComponent<PlayerController>();
		
		
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		transform.Translate(player.move* Time.deltaTime, Space.World);

	}
}
