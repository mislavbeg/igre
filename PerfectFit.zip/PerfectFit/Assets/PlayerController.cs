﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class PlayerController : MonoBehaviour {

	public float speed=0.1f;
	public float shrink = 0.05f;
	public int howManyConsecutive=1;

	public Vector3 move;
	public Vector3 startPosition;
	private CameraController cameraController;

	public bool isPowerUp = false;
	public ParticleSystem particleTrail;
	public float particleWidth;

	public ParticleSystem.MainModule mainModule;
	public ScoreManager scoreManager;

	// Use this for initialization
	void Start () {
		scoreManager = GameObject.Find("ScoreManager").GetComponent<ScoreManager>();
		cameraController = GameObject.Find("CameraHolder").GetComponent<CameraController>();
		particleTrail= GameObject.Find("ParticleTrail").GetComponent<ParticleSystem>();
		particleWidth = 1.4f;
		StartCoroutine("RestartPlus");

		mainModule=particleTrail.main;

		speed += GameManager.gameManager.speedBoost* GameManager.gameManager.currentLvl;

	}
	
	// Update is called once per frame
	void FixedUpdate () {

		
		
		transform.Translate(move*Time.deltaTime);


		if (Input.GetMouseButton(0) && move!=Vector3.zero && !isPowerUp)
		{
			transform.localScale = new Vector3(transform.localScale.x-shrink, transform.localScale.y+shrink/2, transform.localScale.z);
			mainModule.startSize = new ParticleSystem.MinMaxCurve(mainModule.startSize.constant-shrink/3);
			

			if (transform.localScale.x<=0)
			{
				StartCoroutine("Restart");
			}
		}
		


	}

	public IEnumerator ResetSize()
	{
		while (transform.localScale.x<4 && !isPowerUp)
		{
			transform.localScale = new Vector3(transform.localScale.x + 4*shrink, transform.localScale.y - 2*shrink , transform.localScale.z);
			mainModule.startSize = new ParticleSystem.MinMaxCurve(mainModule.startSize.constant + shrink * 4/3);
			yield return new WaitForEndOfFrame();
		}
		if (!isPowerUp)
		{
			transform.localScale = new Vector3(4, 1, 1);
			mainModule.startSize = new ParticleSystem.MinMaxCurve(particleWidth);
		}
		
		yield return null;
	}

	public IEnumerator PowerUp()
	{		
		Vector3 scale = transform.localScale;
		
		if (SegmentController.playerCounter==3)
		{			
			move *= 2;			
			isPowerUp = true;
			StartCoroutine("SetSize", 6);

		}
		else
		{
			move /= 2;
			isPowerUp = false;			
			scoreManager.edge.GetComponent<Image>().sprite = scoreManager.pointsEdge[0];
			scoreManager.edge.SetActive(false);
			StartCoroutine("SetSize", 4);
			Destroy(GameObject.Find("TextPop(Clone)"));
		}		
		yield return null;
	}

	public void StartRestart()
	{
		StartCoroutine("Restart");
	}

	public IEnumerator Restart()
	{
		GameManager.gameManager.StartCoroutine("ResetVariables");
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
		if (GameManager.gameManager.currentLvl>1)
		{
			GameManager.gameManager.StartCoroutine("Next");
		}
		yield return null;			
	}


	public IEnumerator RestartPlus()
	{ 
		
		scoreManager.StartCoroutine("Countdown");
		move = Vector3.zero;
		yield return new WaitForSeconds(3);
		move = transform.forward * speed;
	}

	public IEnumerator Finish()
	{

		
		float help = speed/100;

		while (speed>0)
		{			
			speed -= help;			
			move = transform.forward * speed;
			yield return new WaitForEndOfFrame();
		}
		move = Vector3.zero;
	
		if (GameManager.gameManager.bestScore < scoreManager.playerScore)
		{
			GameManager.gameManager.bestScore = scoreManager.playerScore;
		}

		

		GameObject end = GameManager.gameManager.endScreen.transform.GetChild(0).gameObject;

		
		end.SetActive(true);
		end.transform.Find("TextScore").GetComponent<Text>().text = scoreManager.playerScore.ToString();
		end.transform.Find("TextBest").GetComponent<Text>().text = GameManager.gameManager.bestScore.ToString();

		Destroy(GameObject.Find("TextPop(Clone)"));
		SegmentController.playerCounter = 3;

		
	}

	public IEnumerator SetSize(float sizeu)
	{
		if (transform.localScale.x < sizeu)
		{
			while (transform.localScale.x < sizeu)
			{
				transform.localScale = new Vector3(transform.localScale.x + 4 * shrink, 1, 1);
				mainModule.startSize = new ParticleSystem.MinMaxCurve(mainModule.startSize.constant + shrink * 4 / 3);
				yield return new WaitForEndOfFrame();
			}
		}
		else
		{
			while (transform.localScale.x > sizeu)
			{
				transform.localScale = new Vector3(transform.localScale.x - 4 * shrink, 1, 1);
				mainModule.startSize = new ParticleSystem.MinMaxCurve(mainModule.startSize.constant - shrink * 4 / 3);
				yield return new WaitForEndOfFrame();
			}
			
		}
		
	}


	public void MyNextLevel()
	{
		GameManager.gameManager.NextLevel();
	}
}
