﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour {

	public float playerScore=0;

	public int increment=5;
	public int bonusIncrement=20;
	private int consecutivePerfect;

	public Text scoreText;
	public GameObject numbersPop;
	public GameObject textPop;
	public Sprite[] pointsPrompt = new Sprite[4];
	public GameObject edge;
	public Sprite[] pointsEdge = new Sprite[3];

	GameObject temp2;
	void Start () {
		
	}
	
	void Update () {
		
	}

	public void UpdateScore(bool perfect)
	{
		if (GameObject.Find("Player").GetComponent<PlayerController>().isPowerUp)
		{
			return;
		}
		else
		{//bug
			GameObject.Find("Player").GetComponent<PlayerController>().StartCoroutine("ResetSize");
			if (perfect)
			{
				consecutivePerfect++;
				playerScore += bonusIncrement * Mathf.Pow(2, consecutivePerfect - 1);
				if (consecutivePerfect == GameObject.Find("Player").GetComponent<PlayerController>().howManyConsecutive )
				{
					
					GameObject.Find("Player").GetComponent<PlayerController>().StartCoroutine("PowerUp");
					
				}
			}
			else
			{
				consecutivePerfect = 0;
				playerScore += increment;
			}
			
			ShowMessage();
		}	
		
	}

	public IEnumerator ResetScore()
	{
		yield return new WaitForSeconds(Time.deltaTime);
		playerScore = 0;
		scoreText.text = "0";
		consecutivePerfect = 0;
	}

	public void ShowMessage()
	{
		scoreText.text = playerScore.ToString();
		GameObject temp1 = Instantiate(numbersPop,GameObject.Find("CanvasMenu").transform);
		Destroy(temp1, 0.9f);
		Destroy(temp2);

		if (consecutivePerfect>0)
		{
			
			if (consecutivePerfect>1)
			{
				if (consecutivePerfect ==2)
				{
					edge.SetActive(true);
				}
				else
				{

					edge.GetComponent<Image>().sprite = pointsEdge[consecutivePerfect - 2];
				}
			}
			
			temp2 = Instantiate(textPop, GameObject.Find("CanvasMenu").transform);
			temp2.GetComponent<Image>().sprite = pointsPrompt[consecutivePerfect-1];
			temp1.GetComponent<Text>().text = "+" + (bonusIncrement * Mathf.Pow(2, consecutivePerfect - 1)).ToString() + "!!!";
			if (consecutivePerfect == GameObject.Find("Player").GetComponent<PlayerController>().howManyConsecutive)
			{
				consecutivePerfect = 0;
			}
		}
		else
		{
			temp1.GetComponent<Text>().text = "+"+increment.ToString()+"!";
			edge.GetComponent<Image>().sprite = pointsEdge[0];
			edge.SetActive(false);
		}
		
		
	}

	public IEnumerator Countdown()
	{
		for (int i = 3; i > 0; i--)
		{
			GameObject temp1 = Instantiate(numbersPop, GameObject.Find("CanvasMenu").transform);
			temp1.GetComponent<Text>().text = i.ToString();
			Destroy(temp1, 0.9f);
			yield return new WaitForSeconds(1);
		}

		GameObject temp2 = Instantiate(numbersPop, GameObject.Find("CanvasMenu").transform);
		temp2.GetComponent<Text>().text = "GO!";
		Destroy(temp2, 0.9f);

	}
}
