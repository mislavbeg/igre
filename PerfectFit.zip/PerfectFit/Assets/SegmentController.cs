﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SegmentController : MonoBehaviour {

	public float wallsWidth;
	public float holeWidth;
	private Transform lvlSegment;
	private GameObject floor1;
	private GameObject holeL;
	private GameObject holeR;
	private GameObject wallL;
	private GameObject wallR;

	public GameObject player;
	public ScoreManager scoreManager;

	public float marginOfError=0.1f;
	private float error;
	public float pushPower = 10;
	public static float playerCounter=3;
	// Use this for initialization
	void Start () {
		//MASNI BUG ZA ORGIINAKLNI ZADATAK

		lvlSegment = transform.parent;
		floor1 = lvlSegment.Find("floor (1)").gameObject;
		holeL = lvlSegment.Find("holeL").GetChild(0).gameObject;
		holeR = lvlSegment.Find("holeR").GetChild(0).gameObject;
		wallL = lvlSegment.Find("wallL").GetChild(0).gameObject;
		wallR = lvlSegment.Find("wallR").GetChild(0).gameObject;
		
		//udaljenost zidova
		wallsWidth = floor1.GetComponent<BoxCollider>().bounds.size.x - 2 * (wallL.transform.GetComponent<BoxCollider>().bounds.size.x);
		holeWidth = floor1.GetComponent<BoxCollider>().bounds.size.x - 2 * (holeL.GetComponent<BoxCollider>().bounds.size.x);

		player = GameObject.Find("Player");
		scoreManager = GameObject.Find("ScoreManager").GetComponent<ScoreManager>();

	}
	
	// Update is called once per frame
	void FixedUpdate () {
		
	}

	public void OnTriggerEnter(Collider other)
	{
		if (other.name=="Collider" && player.GetComponent<PlayerController>().isPowerUp)
		{			
				wallR.transform.parent.GetComponent<Rigidbody>().AddRelativeForce((new Vector3(-7, 0, 0)) * pushPower, ForceMode.Impulse);
				wallL.transform.parent.GetComponent<Rigidbody>().AddRelativeForce((new Vector3(-7, 0, 0)) * pushPower, ForceMode.Impulse);					
			
		}
		
	}

	public void OnTriggerStay(Collider other)
	{
		if (other.name == "Collider" && !player.GetComponent<PlayerController>().isPowerUp)
		{			
				float playerWidth = player.GetComponentInChildren<BoxCollider>().bounds.size.x;

				if (playerWidth > wallsWidth || playerWidth < holeWidth)
				{
					player.GetComponent<PlayerController>().StartCoroutine("Restart");
				}
				else
				{
					error = (wallsWidth - playerWidth) / wallsWidth;
				}
		}
	}

	public void OnTriggerExit(Collider other)
	{
		if (other.name== "Collider")
		{
			if (player.GetComponent<PlayerController>().isPowerUp)
			{
				playerCounter--;
			}
			else
			{

				player.GetComponent<PlayerController>().StartCoroutine("ResetSize");		
				//player.GetComponent<PlayerController>().transform.localScale = new Vector3(4, 1, 1);
				//player.GetComponent<PlayerController>().mainModule.startSize = new ParticleSystem.MinMaxCurve(1.4f);
				scoreManager.UpdateScore(error < marginOfError);
				wallR.transform.parent.GetComponent<Rigidbody>().AddRelativeForce((new Vector3(-1, 0, 0)) * pushPower, ForceMode.Impulse);
				wallL.transform.parent.GetComponent<Rigidbody>().AddRelativeForce((new Vector3(-1, 0, 0)) * pushPower, ForceMode.Impulse);
			}

			if (playerCounter==0)
			{
				player.GetComponent<PlayerController>().StartCoroutine("PowerUp");
				playerCounter = 3;
			}
		}


		
		
	}


}
